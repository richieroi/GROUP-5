<?php
$servername = "localhost";
$username = "kingsdev_birthdaysms"; // Change as needed
$password = "birthdaysms@"; // Change as needed
$dbname = "kingsdev_birthdaysms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM Users WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode(array());
    }
}

$conn->close();
?>

<?php
$servername = "localhost";
$username = "kingsdev_birthdaysms"; // Change as needed
$password = "birthdaysms@"; // Change as needed
$dbname = "kingsdev_birthdaysms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get today's date
$today = date('m-d');

// Fetch users with today's birthday
$sql = "SELECT id, name, phone_number FROM Users WHERE DATE_FORMAT(birthday, '%m-%d') = '$today'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $user_id = $row['id'];
        $name = $row['name'];
        $phone_number = $row['phone_number'];
        $messageText = "Happy Birthday, $name!";
        
        // SMS sending logic
        $apiKey = "";
        $messageType = 0; // Modify based on your message type
        $senderID = "KJM SYSTEM";
        $url = "https://api.smsonlinegh.com/v5/message/sms/send";
        $requestData = http_build_query([
            'key' => $apiKey,
            'text' => $messageText,
            'type' => $messageType,
            'sender' => $senderID,
            'to' => $phone_number // Send SMS to the entered phone number
        ]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json'
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        if ($response === false) {
            echo "SMS sending failed.";
        } else {
            echo "SMS sent successfully.";
        }
        curl_close($ch);

        // Log the sent message
        $logSql = "INSERT INTO SentMessages (user_id, message) VALUES ('$user_id', '$messageText')";
        $conn->query($logSql);
    }
} else {
    echo "No birthdays today.";
}

$conn->close();
?>

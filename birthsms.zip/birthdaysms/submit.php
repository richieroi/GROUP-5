<?php
$servername = "localhost";
$username = "kingsdev_birthdaysms"; // Change as needed
$password = "birthdaysms@"; // Change as needed
$dbname = "kingsdev_birthdaysms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $birthday = $_POST['birthday'];

    $sql = "INSERT INTO Users (name, phone_number, birthday) VALUES ('$name', '$phone', '$birthday')";

    if ($conn->query($sql) === TRUE) {
        // SMS sending logic
        $apiKey = "782ff44f6928ada3a44ee78cd5a378d85c53f0c9ffe392306ca0516c9a80e92d";
        $messageText = "Hello $name! You have been added to our birthday wishes system.";
        $messageType = 0; // Modify based on your message type
        $senderID = "KJM SYSTEM";
        $url = "https://api.smsonlinegh.com/v5/message/sms/send";
        $requestData = http_build_query([
            'key' => $apiKey,
            'text' => $messageText,
            'type' => $messageType,
            'sender' => $senderID,
            'to' => $phone // Send SMS to the entered phone number
        ]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers = [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json'
        ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        if ($response === false) {
            echo "SMS sending failed.";
        } else {
            echo "SMS sent successfully.";
        }
        curl_close($ch);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

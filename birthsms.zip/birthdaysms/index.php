<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KJM SYSTEM Birthday Wish Web App</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }
        .container {
            margin-top: 30px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #007bff;
            color: #fff;
            border-bottom: none;
            border-radius: 10px 10px 0 0;
        }
        .card-title {
            font-size: 1.5rem;
        }
        .alert {
            display: none;
        }
        @media (max-width: 768px) {
            .card-title {
                font-size: 1.2rem;
            }
            .modal-dialog {
                max-width: 90%;
                margin: 1.75rem auto;
            }
            .table-responsive {
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">KJM SYSTEM BIRTHDAY WISH WEB APP</h2>
                    </div>
                    <div class="card-body">
                        <p>This app was created by our group called: CE Group 1</p>
                        <div class="balance-card">
                            <h2>SMS API Balance</h2>
                            <?php
                            $apiKey = '782ff44f6928ada3a44ee78cd5a378d85c53f0c9ffe392306ca0516c9a80e92d';  // Replace with your API key
                            
                            // Initialize cURL session
                            $ch = curl_init();
                            
                            // Set cURL options
                            curl_setopt($ch, CURLOPT_URL, 'https://api.smsonlinegh.com/v4/report/balance');
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
                            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                'Content-Type: application/x-www-form-urlencoded',
                                'Accept: application/json',
                                'Authorization: key ' . $apiKey
                            ));
                            
                            // Execute cURL session and get the response
                            $response = curl_exec($ch);
                            
                            // Check for cURL errors
                            if(curl_errno($ch)) {
                                echo 'Error:' . curl_error($ch);
                            } else {
                                $data = json_decode($response, true);
                                
                                if(isset($data['handshake']['label']) && $data['handshake']['label'] == "HSHK_OK") {
                                    echo "Credit Balance: " . $data['data']['balance']['amount'] .  "";
                                } else {
                                    echo "Failed to retrieve balance.";
                                }
                            }
                            
                            // Close cURL session
                            curl_close($ch);
                            ?>
                        </div>
                        
                        <div class="api-key-box">
                            <h2>SMS API Key</h2>
                            <div class="api-key-content">
                                782ff44f6928ada3a44ee78cd5a378d85c53f0c9ffe392306ca0516c9a80e92d
                            </div></br>
                            <h5>900 Credits = GHS60/Month</h5>
                        </div>
                        
                        </br>
                        <div class="section">
                            <div class="button-container">
                                <button type="button" class="btn btn-primary button" data-toggle="modal" data-target="#bankDetailsModal">
                                    Buy Credit for KJM SYSTEM
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Bank Details Modal -->
        <div class="modal fade" id="bankDetailsModal" tabindex="-1" role="dialog" aria-labelledby="bankDetailsModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="bankDetailsModalLabel">Bank Details for KJM SYSTEM Credit Purchase</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Please use the following bank details to make a payment:</p>
                        <ul>
                            <li><strong>Bank Name:</strong> XYZ Bank</li>
                            <li><strong>Account Name:</strong> KJM SYSTEM</li>
                            <li><strong>Account Number:</strong> 1234567890</li>
                            <li><strong>Branch:</strong> Accra Main Branch</li>
                        </ul>
                        <p>After making the payment, please contact us with the payment details to confirm your purchase.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row">
           <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="alert alert-success" id="successAlert" role="alert">
                    User added successfully!
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Add New User</h2>
                    </div>
                    <div class="card-body">
                        <form id="userForm" action="submit.php" method="post">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="text" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="form-group">
                                <label for="birthday">Birthday</label>
                                <input type="date" class="form-control" id="birthday" name="birthday" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Add User</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">User List</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="userTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Phone Number</th>
                                        <th>Birthday</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- User rows will be inserted here by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Our Project Overview:</h2>
                    </div>
                    <div class="card-body">
                      
                        <p>
                            The KJM System Birthday Wish Web App is designed to automate the process of sending birthday wishes via SMS to users. This project aims to simplify the way birthday greetings are managed and ensure that no birthday goes unnoticed.
                        </p>
                        <p><strong>Features:</strong></p>
                        <ul>
                            <li><strong>Add New Users:</strong> Users can be added to the system with their name, phone number, and birthday details.</li>
                            <li><strong>User List:</strong> View a list of all users with their details. The list is responsive and scrollable on mobile devices.</li>
                            <li><strong>Edit and Delete Users:</strong> Update or remove user information as needed.</li>
                            <li><strong>Automated Birthday Wishes:</strong> Automatically sends birthday wishes via SMS to the users on their special day.</li>
                        </ul>
                        <p><strong>Technical Details:</strong></p>
                        <ul>
                            <li><strong>Frontend:</strong> Built using HTML, CSS, and Bootstrap for a responsive and modern user interface.</li>
                            <li><strong>Backend:</strong> Powered by PHP to handle user data management and SMS sending logic.</li>
                            <li><strong>Database:</strong> Utilizes a MySQL database to store user information securely.</li>
                        </ul>
                        <p><strong>Future Enhancements:</strong></p>
                        <ul>
                            <li>Adding email notifications alongside SMS.</li>
                            <li>Integrating with social media platforms for broader reach.</li>
                            <li>Implementing a dashboard for detailed analytics and user engagement metrics.</li>
                        </ul>
                        <p><strong>Team:</strong></p>
                        <p>
                            The project was developed by CE Group 1, a team of dedicated and skilled developers committed to delivering quality software solutions.
                        </p>
                        <p><strong>Contact Information:</strong></p>
                        <p>
                            For more information, please contact us at <a href="mailto:cegroup1@example.com">cegroup1@example.com</a>.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>    

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editUserForm">
                        <input type="hidden" id="editUserId" name="id">
                        <div class="form-group">
                            <label for="editName">Name</label>
                            <input type="text" class="form-control" id="editName" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="editPhone">Phone Number</label>
                            <input type="text" class="form-control" id="editPhone" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="editBirthday">Birthday</label>
                            <input type="date" class="form-control" id="editBirthday" name="birthday" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Delete User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this user?
                    <form id="deleteUserForm">
                        <input type="hidden" id="deleteUserId" name="id">
                        <button type="submit" class="btn btn-danger">Delete</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            // Function to fetch users and display them in the table
            function fetchUsers() {
                $.ajax({
                    url: 'fetch_users.php',
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        var rows = '';
                        response.forEach(function(user) {
                            rows += '<tr>';
                            rows += '<td>' + user.id + '</td>';
                            rows += '<td>' + user.name + '</td>';
                            rows += '<td>' + user.phone_number + '</td>';
                            rows += '<td>' + user.birthday + '</td>';
                            rows += '<td><button class="btn btn-warning btn-sm editBtn" data-id="' + user.id + '">Edit</button> <button class="btn btn-danger btn-sm deleteBtn" data-id="' + user.id + '">Delete</button></td>';
                            rows += '</tr>';
                        });
                        $('#userTable tbody').html(rows);
                    }
                });
            }

            fetchUsers();

            // Edit button click event
            $(document).on('click', '.editBtn', function() {
                var userId = $(this).data('id');
                $.ajax({
                    url: 'get_user.php',
                    method: 'GET',
                    data: { id: userId },
                    dataType: 'json',
                    success: function(response) {
                        $('#editUserId').val(response.id);
                        $('#editName').val(response.name);
                        $('#editPhone').val(response.phone_number);
                        $('#editBirthday').val(response.birthday);
                        $('#editModal').modal('show');
                    }
                });
            });

            // Update user form submission
            $('#editUserForm').on('submit', function(event) {
                event.preventDefault();
                $.ajax({
                    url: 'update_user.php',
                    method: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        $('#editModal').modal('hide');
                        fetchUsers();
                    }
                });
            });

            // Delete button click event
            $(document).on('click', '.deleteBtn', function() {
                var userId = $(this).data('id');
                $('#deleteUserId').val(userId);
                $('#deleteModal').modal('show');
            });

            // Delete user form submission
            $('#deleteUserForm').on('submit', function(event) {
                event.preventDefault();
                $.ajax({
                    url: 'delete_user.php',
                    method: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        $('#deleteModal').modal('hide');
                        fetchUsers();
                    }
                });
            });

            // Add user form submission
            $('#userForm').on('submit', function(event) {
                event.preventDefault();
                $.ajax({
                    url: $(this).attr('action'),
                    method: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function(response) {
                        $('#successAlert').fadeIn().delay(3000).fadeOut();
                        $('#userForm')[0].reset(); // Reset form fields
                        fetchUsers(); // Refresh user list
                    }
                });
            });
        });
    </script>
</body>
</html>
